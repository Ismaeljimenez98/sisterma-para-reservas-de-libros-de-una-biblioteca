﻿using System;
using System.Windows.Forms;

namespace Sistema_de_Reserva.Views
{
    partial class LibroForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            btnAgregarLibro = new Button();
            lblISBN = new Label();
            lblTitulo = new Label();
            lblAutor = new Label();
            lblEditorial = new Label();
            lblAño = new Label();
            lblGenero = new Label();
            lblCopias = new Label();
            txtISBN = new TextBox();
            txtTitulo = new TextBox();
            txtAutor = new TextBox();
            txtEditorial = new TextBox();
            txtAño = new TextBox();
            txtGenero = new TextBox();
            txtCopias = new TextBox();
            SuspendLayout();
            // 
            // btnAgregarLibro
            // 
            btnAgregarLibro.Location = new Point(140, 378);
            btnAgregarLibro.Name = "btnAgregarLibro";
            btnAgregarLibro.Size = new Size(105, 32);
            btnAgregarLibro.TabIndex = 0;
            btnAgregarLibro.Text = "Agregar Libro";
            btnAgregarLibro.UseVisualStyleBackColor = true;
            btnAgregarLibro.Click += btnAgregarLibro_Click;
            // 
            // lblISBN
            // 
            lblISBN.AutoSize = true;
            lblISBN.BackColor = Color.FromArgb(0, 192, 0);
            lblISBN.Location = new Point(86, 57);
            lblISBN.Name = "lblISBN";
            lblISBN.Size = new Size(32, 15);
            lblISBN.TabIndex = 1;
            lblISBN.Text = "ISBN";
            // 
            // lblTitulo
            // 
            lblTitulo.AutoSize = true;
            lblTitulo.BackColor = Color.FromArgb(0, 192, 0);
            lblTitulo.Location = new Point(86, 107);
            lblTitulo.Name = "lblTitulo";
            lblTitulo.Size = new Size(37, 15);
            lblTitulo.TabIndex = 2;
            lblTitulo.Text = "Titulo";
            // 
            // lblAutor
            // 
            lblAutor.AutoSize = true;
            lblAutor.BackColor = Color.FromArgb(0, 192, 0);
            lblAutor.Location = new Point(86, 154);
            lblAutor.Name = "lblAutor";
            lblAutor.Size = new Size(37, 15);
            lblAutor.TabIndex = 3;
            lblAutor.Text = "Autor";
            // 
            // lblEditorial
            // 
            lblEditorial.AutoSize = true;
            lblEditorial.BackColor = Color.FromArgb(0, 192, 0);
            lblEditorial.Location = new Point(86, 199);
            lblEditorial.Name = "lblEditorial";
            lblEditorial.Size = new Size(50, 15);
            lblEditorial.TabIndex = 4;
            lblEditorial.Text = "Editorial";
            // 
            // lblAño
            // 
            lblAño.AutoSize = true;
            lblAño.BackColor = Color.FromArgb(0, 192, 0);
            lblAño.Location = new Point(86, 240);
            lblAño.Name = "lblAño";
            lblAño.Size = new Size(29, 15);
            lblAño.TabIndex = 5;
            lblAño.Text = "Año";
            // 
            // lblGenero
            // 
            lblGenero.AutoSize = true;
            lblGenero.BackColor = Color.FromArgb(0, 192, 0);
            lblGenero.Location = new Point(86, 286);
            lblGenero.Name = "lblGenero";
            lblGenero.Size = new Size(45, 15);
            lblGenero.TabIndex = 6;
            lblGenero.Text = "Genero";
            // 
            // lblCopias
            // 
            lblCopias.AutoSize = true;
            lblCopias.BackColor = Color.FromArgb(0, 192, 0);
            lblCopias.Location = new Point(86, 331);
            lblCopias.Name = "lblCopias";
            lblCopias.Size = new Size(43, 15);
            lblCopias.TabIndex = 7;
            lblCopias.Text = "Copias";
            // 
            // txtISBN
            // 
            txtISBN.Location = new Point(213, 54);
            txtISBN.Name = "txtISBN";
            txtISBN.Size = new Size(100, 23);
            txtISBN.TabIndex = 8;
            txtISBN.Text = "Ingrese ISBN";
            // 
            // txtTitulo
            // 
            txtTitulo.CausesValidation = false;
            txtTitulo.Location = new Point(213, 104);
            txtTitulo.Name = "txtTitulo";
            txtTitulo.Size = new Size(100, 23);
            txtTitulo.TabIndex = 9;
            txtTitulo.Text = "Ingrese Titulo";
            // 
            // txtAutor
            // 
            txtAutor.Location = new Point(213, 151);
            txtAutor.Name = "txtAutor";
            txtAutor.Size = new Size(100, 23);
            txtAutor.TabIndex = 10;
            txtAutor.Text = "Ingrese Autor";
            // 
            // txtEditorial
            // 
            txtEditorial.Location = new Point(213, 196);
            txtEditorial.Name = "txtEditorial";
            txtEditorial.Size = new Size(100, 23);
            txtEditorial.TabIndex = 11;
            txtEditorial.Text = "Ingrese Editorial";
            // 
            // txtAño
            // 
            txtAño.Location = new Point(213, 237);
            txtAño.Name = "txtAño";
            txtAño.Size = new Size(100, 23);
            txtAño.TabIndex = 12;
            txtAño.Text = "Ingrese Año";
            // 
            // txtGenero
            // 
            txtGenero.Location = new Point(213, 283);
            txtGenero.Name = "txtGenero";
            txtGenero.Size = new Size(100, 23);
            txtGenero.TabIndex = 13;
            txtGenero.Text = "Ingrese Genero";
            // 
            // txtCopias
            // 
            txtCopias.Location = new Point(213, 328);
            txtCopias.Name = "txtCopias";
            txtCopias.Size = new Size(147, 23);
            txtCopias.TabIndex = 14;
            txtCopias.Text = "Ingrese Numero de Copias";
            // 
            // LibroForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(394, 450);
            Controls.Add(txtCopias);
            Controls.Add(txtGenero);
            Controls.Add(txtAño);
            Controls.Add(txtEditorial);
            Controls.Add(txtAutor);
            Controls.Add(txtTitulo);
            Controls.Add(txtISBN);
            Controls.Add(lblCopias);
            Controls.Add(lblGenero);
            Controls.Add(lblAño);
            Controls.Add(lblEditorial);
            Controls.Add(lblAutor);
            Controls.Add(lblTitulo);
            Controls.Add(lblISBN);
            Controls.Add(btnAgregarLibro);
            Name = "LibroForm";
            Text = "Gestión de Libros";
            Load += LibroForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        private Button btnAgregarLibro;
        private Label lblISBN;
        private Label lblTitulo;
        private Label lblAutor;
        private Label lblEditorial;
        private Label lblAño;
        private Label lblGenero;
        private Label lblCopias;
        private TextBox txtISBN;
        private TextBox txtTitulo;
        private TextBox txtAutor;
        private TextBox txtEditorial;
        private TextBox txtAño;
        private TextBox txtGenero;
        private TextBox txtCopias;
        // Define aquí más controles como txtTitulo, txtAutor, etc.
    }
}